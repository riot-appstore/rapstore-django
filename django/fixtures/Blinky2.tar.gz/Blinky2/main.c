/*
 * Copyright (C) 2014 Freie Universität Berlin
 *
 * This file is subject to the terms and conditions of the GNU Lesser
 * General Public License v2.1. See the file LICENSE in the top level
 * directory for more details.
 */

/**
 * @ingroup     examples
 * @{
 *
 * @file
 * @brief       Hello World application
 *
 * @author      Kaspar Schleiser <kaspar@schleiser.de>
 * @author      Ludwig Knüpfer <ludwig.knuepfer@fu-berlin.de>
 *
 * @}
 */
#include "periph/gpio.h"
#include "led.h"
#include "xtimer.h"

int main(void)
{

    unsigned char i = 0;
    int timer = 0;
    int countup = 0;
    gpio_init(LED0_PIN, GPIO_OUT);
	while (1)
	{
        if (countup)
        {
            LED0_TOGGLE;
            xtimer_usleep(0xFF  - i);
            LED0_TOGGLE;
            xtimer_usleep(i);
        }
		else
        {
            LED0_TOGGLE;
            xtimer_usleep(i);
            LED0_TOGGLE;
            xtimer_usleep(0xFF  - i);

        }

        timer++;
        if (timer > 2)
        {
            timer = 0;
            i++;
            if (i == 0)
            {
                if (countup)
                {
                    countup = 0;
                }
                else
                {
                    countup = 1;
                }
            }
        }
	}


	return 0;
}
